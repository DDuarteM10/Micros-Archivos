void ConfiguracionUsart2(void);
void SendUsart2(char Menu,char valorChart[],int valorInt,float valorFloat);