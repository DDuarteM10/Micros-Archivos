void ReadGY271 (void);
void IniciarGY271(void);
extern int  x,y;