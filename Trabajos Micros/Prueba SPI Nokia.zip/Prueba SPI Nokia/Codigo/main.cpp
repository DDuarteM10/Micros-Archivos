#include "stm32f4xx.h"                  // Device header
#include "Nokia.h"
#include "stdio.h"
char inicio[7]={'H','o','l','a',' ','B','B'};
char inicio2[]={"Espejo ayuda"};
int main(void){
		Nokia_5110(0xFA);
		Escribir_nokia_0(1,1,1,inicio2,1);
	while(1){
		
	}
}