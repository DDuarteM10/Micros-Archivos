void Enviar4DatosGrafica(float x,float y, float z, float z1);
void IniciarUsart2(void);