void ConfiguracionADC(void);
void LeerADC1(void);
extern int ValADC1;