
char I2CRead(char address,char registry );
void I2CWrite(char address, char registry, char data);
void IniciarI2C(void);