#include "stm32f4xx.h"                  // Device header
#include "math.h"
#include "stdio.h"



//Variables
int Contador=0,Milisegundos=0,RH; 
//Desde LCD
char clear=0x01;
char set=0x38;//
char disp_on=0x0E;//
char mode=0x06; //
char ddram1L=0x80;//linea arriba
char ddram2L=0xC0;//de abajo
//Hasta LCD
char cad[2];
float Resultado=0;
int numeroDigito;
double Velocidad,PeriodoS,Frecuencia,FrecuenciaHz;
void borrado(int a);
 char setX= 0xB8;
 char disp_onG= 0x3F;   //Variables globales pa que funcione
 char disp_off= 0x3e;
 char starL=0xC0;
int x, i ,j;
 char setY=0x40;
char LA[8] = {0x00,0xfc,0x12,0x11,0x11,0x12,0xfc,0x00};
  char LB[8] = {0x00,0xff,0x89,0x89,0x89,0x89,0x76,0x00};
  char LC[8] = {0X00,0X3C,0X42,0X81,0X81,0X81,0X81,0X00};
  char LD[8] = {0x00,0xff,0X81,0X81,0X81,0X42,0X3C,0x00};
  char LE[8] = {0X00,0XFF,0X89,0X89,0X89,0X00,0X00,0X00};
  char LF[8] = {0X00,0XFF,0X09,0X09,0X09,0X09,0X01,0X00};
  char LG[8] = {0x00,0X7E,0X89,0X89,0X89,0X89,0X70,0x00};
  char LH[8] = {0X00,0XFF,0X08,0X08,0X08,0X08,0XFF,0X00};
  char LI[8] = {0X00,0X00,0X81,0X81,0XFF,0X81,0X81,0X00};
  char LJ[8] = {0x00,0X81,0X81,0X81,0X7F,0X01,0X01,0x00};
  char LK[8] = {0x00,0xff,0x18,0x14,0x22,0x41,0x80,0x00};
  char LL[8] = {0x00,0xff,0x80,0x80,0x80,0x80,0x00,0x00};
  char LM[8] = {0x00,0xff,0x01,0x02,0x04,0x02,0x01,0xff};
  char LN[8] = {0x00,0xff,0x03,0x0c,0x30,0xc0,0xff,0x00};  //Vectores letras de 8 bits por tama�o 
  char LO[8] = {0x00,0xff,0x81,0x81,0x81,0x81,0xff,0x00};
  char LP[8] = {0x00,0xff,0x11,0x11,0x11,0x11,0x0e,0x00};
  char LQ[8] = {0x00,0x7e,0x81,0x81,0xa1,0x7e,0x80,0x00};
  char LR[8] = {0x00,0xff,0x09,0x19,0x29,0x49,0x89,0x00};
  char LS[8] = {0x00,0xc0,0x92,0x92,0x92,0x92,0x60,0x00};
  char LT[8] = {0x01,0x01,0x01,0xff,0x01,0x01,0x01,0x00};
  char LU[8] = {0x00,0x7f,0x80,0x80,0x80,0x7f,0x80,0x00};
  char LV[8] = {0x03,0x0c,0x30,0xc0,0xc0,0x30,0x0c,0x03};
  char LW[8] = {0x07,0x38,0xc0,0x30,0xc0,0x38,0x07,0x00};
  char LX[8] = {0x81,0x42,0x24,0x18,0x18,0x24,0x42,0x81};
  char NO[8] = {0x00,0xff,0x81,0x81,0x81,0x81,0xff,0x00};
  char N1[8] = {0x00,0x00,0x84,0x82,0xff,0x80,0x80,0x00};
  char N2[8] = {0x00,0x00,0x62,0x91,0x89,0x86,0x00,0x00};
  char N3[8] = {0x00,0x00,0x42,0x91,0x99,0x66,0x00,0x00};
  char N4[8] = {0x00,0x0c,0x0a,0x09,0xff,0x08,0x00,0x00};
  char N5[8] = {0x00,0x06,0x89,0x89,0x89,0x89,0x70,0x00};
  char N6[8] = {0x00,0x00,0x30,0x4c,0x8a,0x91,0x60,0x00};
  char N7[8] = {0x00,0x00,0x01,0x11,0x11,0xff,0x00,0x00};
  char N8[8] = {0x00,0x20,0x56,0x89,0x89,0x56,0x20,0x00};
  char N9[8] = {0x00,0x00,0x06,0x89,0x49,0x36,0x00,0x00};
char NUM[10][4] ={0x1f,0x11,0x1f,0x00, //0
									0x12,0x1f,0x10,0x00, //1
									0x19,0x15,0x13,0x00,  //2
									0x11,0x15,0x1f,0x00, //3
									0x07,0x04,0x1f,0x00, //4
									0x13,0x15,0x19,0x00, //5     //Vectores para los numeros de la variable de 4 bits 
									0x1f,0x15,0x1c,0x00, //6
									0x01,0x05,0x1f,0x00, //7
                                                                         0x1f,0x15,0x1f,0x00, //8
									0x07,0x05,0x1f,0x00}; //9



									
									
									
									
									
void Daley(void){
	
	for(int timer=0;timer<55000;timer++){
		__NOP();

		}
	}
void send_comandoG(int cs, char a){
 GPIOD->ODR = a; 
 if(cs==1){GPIOD ->ODR |=(1UL<<8);}  
 else if(cs==2){GPIOD ->ODR |=(1UL<<9);} 
 GPIOD->ODR |=(1UL<<11);              
 for(int Cont=0;Cont<200;Cont++);
 GPIOD->ODR &=~(1UL<<11);  
 GPIOD->ODR =0;   
 }
                                           //funciones para enviar datos y ordenes a la lcd 
 void send_datoG(int cs, char b){            //Enable conectado al pin 11 Cr1 pin 8 Cr2 pin 9 RS pin 10
 GPIOD->ODR |=(1UL<<10); 
 if(cs==1){GPIOD ->ODR |=(1UL<<8);}  
 else if(cs==2){GPIOD ->ODR |=(1UL<<9);}  
 GPIOD ->ODR |= b;
 GPIOD->ODR |=(1UL<<11);  
 for(int Cont=0;Cont<200;Cont++);
 GPIOD->ODR &=~(1UL<<11);  
 GPIOD->ODR =0; 
 } 
 
 void borrado(int a){
    for(i = 0; i < 8; ++i){//8 paginas
       send_comandoG(1,setY);//1=parte izquierda
       send_comandoG(2,setY);//2=parte derecha
       send_comandoG(1, i | setX);
       send_comandoG(2, i | setX);
       for(j = 0; j < 64; ++j)
       {  send_datoG(1, 0x00*a); 
          send_datoG(2, 0x00*a);  
       }
    }
 }
extern"C"{
	void EXTI0_IRQHandler(void){
		EXTI ->PR |= 0x1;
		Contador++;
	}
	void SysTick_Handler (void){
		Milisegundos++;
		if(Milisegundos==500){//500 ms
			Frecuencia=(Contador/0.5);
			Velocidad = (Frecuencia/60);//rpms
			Contador=0;
			
		}
	}
}
void Configuracion(void){
	//reloj Puertos e interrupciones
	RCC->AHB1ENR |= 0xF;
	RCC->APB2ENR |= (1UL<<14);
	//Puerto A
	GPIOA->MODER |=0x0;
	//Puerto C
	GPIOC->MODER |=0x55555;
	GPIOB->MODER |=0x1;
	GPIOD->MODER|=0x55555555;
	//Interrupciones
	SYSCFG->EXTICR[0] = 0x0;
	NVIC_EnableIRQ(EXTI0_IRQn);
	EXTI->IMR |= 0x1;
	EXTI->EMR |= 0x1;
	EXTI->RTSR |= 0x1;
	EXTI ->PR |= 0x1;
	//Uso de systick
	SysTick_Config(SystemCoreClock/1000);
	SystemCoreClockUpdate();
}
void send_comando(char a){//envia dato
GPIOC->ODR=a|(1UL<<9);
for(int i=0;i<500000;i++){__NOP();}
GPIOC->ODR&=~(1UL<<9);
}
void send_dato(char b){
GPIOC->ODR=b|(3<<8);
for(int i=0;i<500000;i++){__NOP();}
GPIOC->ODR&=~(1UL<<9);
}
void entro_a_cadena(int n){//Omitir
	//Contar la cantidad de digitos n
  numeroDigito=0;
	int aux=n;
	while(aux>0){
		aux=aux/10;
		numeroDigito++;
	}
	cad[numeroDigito] = '\0';
	aux=n;
	int pos=numeroDigito-1,digito;
	while(pos>=0){
		digito = aux%10;
		aux = aux/10;
		cad[pos]=digito + 0x0;
		pos--;
	}
}
int main(void){
	Configuracion();
	send_comando(clear); // limpiar 
	send_comando(set);	//
	send_comando(disp_on);
	send_comando(mode);
	send_comando(ddram1L);//activa linea 1

	send_comando(ddram1L);
	Daley();
	send_comando(clear);
	send_comando(ddram1L);
	Daley();
	send_comando(clear);
	
	send_comando(ddram2L);
	 send_comandoG(1,starL);
 send_comandoG(2,starL);
 send_comandoG(1,setY);
 send_comandoG(2,setY);
 send_comandoG(1,setX);
 send_comandoG(2,setX);
 send_comandoG(1,disp_onG);
 send_comandoG(2,disp_onG);
 borrado(0);
	
	
	
	while(1){
		Resultado=Velocidad;
		RH=round(Resultado);
		//entro_a_cadena(RH);
		//cad=sprintf(cad,"",RH);
		int decenas=RH/10;
		int unidades=RH-(decenas*10);
		send_dato(decenas+0x30);//Convierte a Char
		send_dato(unidades+0x30);//Convierte a Char
		
		send_dato('r');
		send_dato('p');
		send_dato('m');
		for(int contador=0;contador<20000;contador++){
		__NOP();
		}
		
		send_comando(ddram2L);
		int c1= RH/100;
			 int d1=(RH-(c1*100))/10;
			 int u1= RH%10;
			 send_comandoG(2,setY);
       send_comandoG(2, setX);
       for(j = 0; j < 8; ++j)
       {  send_datoG(2,LR[j] );}//Envia R
       for(j = 0; j < 8; ++j)
       {  send_datoG(2,LP[j] );}//Envia P
			 for(j = 0; j < 8; ++j)
       {  send_datoG(2,LM[j] );}//Envia M
			  send_comandoG(2,setY+10);
       send_comandoG(2, 2 | setX);
			 for(j = 0; j < 4; ++j)
       {  send_datoG(2,NUM[c1][j]);}
			 for(j = 0; j < 4; ++j)
       {  send_datoG(2,NUM[d1][j]);}   // para mostrar los numeros de que necesite de 4 bits
			 for(j = 0; j < 4; ++j)          // a la variable le saca unidades decenas y centenas
       {  send_datoG(2,NUM[u1][j]);}
			 for(j = 0; j < 50000; ++j)
       {__NOP();}
		
	}
}