
#include "stm32f4xx.h"                 
#include "stdio.h"

int Canal;
int bits0_7;
int bits8_12;
int minimenu = 0;
int temp, decenas,unidades, contador=0;
long Dela;
int contador2 =0 ;
char variable[30];
int contador3=1;
int x;
///////////////////////Congifuracion puertos   B14, B15
void Configuracion(void){
	//Clock Puertos, ADC y USAR
	RCC -> AHB1ENR |=0x1F; //Puertos A B C D E
	RCC -> APB1ENR |=(1UL<<17); //USAR 2
	RCC -> APB2ENR |=0x700; //ADC 1, 2 y 3
	//GPIOA USAR 2
	GPIOA -> MODER |=0xA0;  //especial 3 y 2 
	//GPIOB
	GPIOB-> MODER |= 0x0; //PB como entrada
	//GPIOC  
	GPIOC -> MODER |=0xA;  //0 y 1 analogo
	//GPIOD todos Salida
	GPIOD -> MODER |=0x55555555;  
	//GPIOE Nada
	////////// USART //////////////
	RCC->APB1ENR |= (1UL<<17); // Enable clock for UART2
	USART2->BRR = 0x683; // 9600 baud
	USART2->CR1 = 0x2D; // Enable UART for TX, RX
	GPIOA->AFR[0] |= 0x7700; // select AF8 (UART2) for PA2, PA3 PIN 2 Y 3
	//USART2->CR1    |= 0x0020;      // Enable RX interrupt
	NVIC_EnableIRQ(USART2_IRQn);
	////////// ADC //////////////
	ADC1->CR2 = ADC_CR2_ADON;
	//////// Interrupci�n /////////
	SYSCFG->EXTICR[3]= 0x2200; //Interrupci�n en PB14 y PB15
	EXTI->IMR=0xC000; // Desenmascarar PB14 y PB15
	EXTI->RTSR=0xC000; // Flanco de subida en PB14 y PB15
	NVIC_EnableIRQ(EXTI15_10_IRQn); //Habilita Interrupciones en PB14 y PB15
	
	

}
void Delay(int limite) {
	for (int timer = 0; timer < limite;timer++) { __NOP(); }
}
void send_Usar2(int Dato) {
	USART2->DR = Dato;
}
int get_Usar2() {
	int x;
		x = USART2->DR;
	return x;
}
extern"C" {
	/* void USAR2_IRQHandler(void) {

	}*/
	void ADC1_IRQHandler(void) {
		bits0_7 = (ADC1->DR & 0xcFF);
		bits8_12 = ((ADC1->DR>>8) & 0xFF);
		send_Usar2(bits0_7);
		Delay(50000);
		send_Usar2(bits8_12);
		Delay(50000);
	}
	void USART2_IRQHandler(void)    
			{	 
				if(USART2->SR & 0x20){//Termin� de recibir?
				x = USART2->DR;
				if (x==0) {//00 Pot
				ADC1->SQR3 = 10;
				ADC1->CR2 |= (1UL<<30);//Comenzar la conversion
				temp = (ADC1 -> DR);
				sprintf(variable,"%d\r\n",temp);
				while(variable[contador2]|=0){
				for(long x=0;x<100000;x++){__NOP();}
				USART2 -> DR=(variable[contador2]);
				contador2++;
		}
		if (x ==1) {//01 Temperatura
			ADC1->SQR3 = 11;
			ADC1->CR2 |= (1UL<<30);//Comenzar la conversion
			temp = (ADC1 -> DR);
			sprintf(variable,"%d\r\n",temp);
			while(variable[contador2]|=0){
			for(long x=0;x<100000;x++){__NOP();}
			USART2 -> DR=(variable[contador2]);
			contador2++;
		}
		}
	}
				}
			}
	void EXTI15_10_IRQHandler(void) {
		minimenu = GPIOB->IDR >> 14;
}
	}


///////////////////////Int  main
int main(void){
	Configuracion();
    ADC1 -> SQR3 = Canal; //Canal varia entre 10 y 11 dependiento cu�l se quiera transmitir

	while (true){
		ADC1->CR2 |= ADC_CR2_SWSTART; // El ADC1 comienza a operar
		while((ADC1->SR & ADC_SR_EOC)==0);
		ADC1->SR = 0;

		ADC1 -> DR = GPIOC->ODR;

	}
}